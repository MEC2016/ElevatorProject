/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _RUNTIME_
#define _RUNTIME_

#include <bur/plctypes.h>

#ifndef _IEC_CONST
#define _IEC_CONST _WEAK const
#endif

/* Constants */
#ifdef _REPLACE_CONST
 #define ERR_OK 0
 #define ERR_NOTIMPLEMENTED 9999
 #define ERR_FUB_ENABLE_FALSE 0xFFFE
 #define ERR_FUB_BUSY 0xFFFF
#else
 _IEC_CONST unsigned short ERR_OK = 0U;
 _IEC_CONST unsigned short ERR_NOTIMPLEMENTED = 9999U;
 _IEC_CONST unsigned short ERR_FUB_ENABLE_FALSE = 0xFFFEU;
 _IEC_CONST unsigned short ERR_FUB_BUSY = 0xFFFFU;
#endif

#endif /* _RUNTIME_ */

